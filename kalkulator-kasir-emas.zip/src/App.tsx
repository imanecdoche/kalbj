/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Delete, RotateCcw, ChevronRight, Check, Settings, X, Plus, Receipt, History, Trash2 } from 'lucide-react';
import { motion, AnimatePresence, useSpring, useTransform } from 'motion/react';
import { simpanTransaksi, loadTransaksi, hapusTransaksi, hapusSemuaTransaksi, Transaksi } from './firebase';

// --- Utils for Feedback ---
const vibrate = () => {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    navigator.vibrate(10);
  }
};

const playSoftBeep = () => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const audioCtx = new AudioContextClass();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
    
    gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.05, audioCtx.currentTime + 0.02); // soft fade in
    gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.15); // soft fade out
    
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    
    oscillator.start(audioCtx.currentTime);
    oscillator.stop(audioCtx.currentTime + 0.2);
  } catch (e) {
    console.error('Audio synthesis failed', e);
  }
};

interface Presets {
  [key: string]: string;
}

interface CartItem {
  id: string;
  label: string;
  pricePerGram: number;
  gram: number;
  totalSebelum: number;
  totalAkhir: number;
}

const PRESET_ORDER = ['8KP', '8KS', '16KP', '16KS', '17KP', '17KS', '21K'];

const defaultPresets: Presets = {
  '8KP': '450000',
  '8KS': '400000',
  '16KP': '650000',
  '16KS': '600000',
  '17KP': '750000',
  '17KS': '700000',
  '21K': '900000',
};

function pembulatanRibuan(n: number) {
  let sisa = n % 1000;
  if (sisa >= 500) {
    return n + (1000 - sisa);
  } else {
    return n - sisa;
  }
}

const formatHargaKasir = (valStr: string) => {
  const v = valStr || '0';
  const padded = v.padStart(7, '0');
  return padded.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
};

const formatRupiah = (val?: number | null) => {
  if (val === undefined || val === null || isNaN(val)) return '0';
  return val.toLocaleString('id-ID');
};

function AnimatedNumber({ value }: { value: number }) {
  const spring = useSpring(value, { mass: 0.8, stiffness: 75, damping: 15 });
  const display = useTransform(spring, (current) => formatRupiah(Math.round(current)));

  useEffect(() => {
    spring.set(value);
  }, [spring, value]);

  return <motion.span>{display}</motion.span>;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<1 | 2 | 3 | 4>(1);
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);
  const [harga, setHarga] = useState<string>('');
  const [gram, setGram] = useState<string>('');
  const [presets, setPresets] = useState<Presets>(() => {
    const saved = localStorage.getItem('gold_presets');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed['6KS']) {
        parsed['8KS'] = parsed['6KS'];
        delete parsed['6KS'];
      }
      if (parsed['6KP']) {
        parsed['8KP'] = parsed['6KP'];
        delete parsed['6KP'];
      }
      return parsed;
    }
    return defaultPresets;
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isLabelModalOpen, setIsLabelModalOpen] = useState(false);
  const [isCustomLabel, setIsCustomLabel] = useState(false);
  const [itemLabel, setItemLabel] = useState("");
  const labelInputRef = useRef<HTMLInputElement>(null);
  const [isGrandTotalOpen, setIsGrandTotalOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<'GRAND_TOTAL' | null>(null);

  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [selectedRiwayat, setSelectedRiwayat] = useState<Transaksi | null>(null);

  const [riwayatList, setRiwayatList] = useState<Transaksi[]>([]);
  const [isLoadingRiwayat, setIsLoadingRiwayat] = useState(false);

  const fetchRiwayat = async () => {
    setIsLoadingRiwayat(true);
    try {
      const data = await loadTransaksi();
      setRiwayatList(data);
    } catch (error) {
      console.error("Gagal memuat riwayat", error);
    }
    setIsLoadingRiwayat(false);
  };

  useEffect(() => {
    if (activeTab === 4) {
      fetchRiwayat();
    }
  }, [activeTab]);
  useEffect(() => {
    localStorage.setItem('gold_presets', JSON.stringify(presets));
  }, [presets]);

  const handleHargaInput = (key: string) => {
    setSelectedPreset(null);
    if (key === 'C') {
      setHarga('');
      return;
    }
    if (key === '⌫') {
      setHarga((prev) => prev.slice(0, -1));
      return;
    }
    if (key === '00' && harga === '') return;
    if (key === '0' && harga === '') return;
    if (harga.length >= 10) return; // limit digits
    setHarga((prev) => prev + key);
  };

  const handleGramInput = (key: string) => {
    if (key === 'C') {
      setGram('');
      return;
    }
    if (key === '⌫') {
      setGram((prev) => prev.slice(0, -1));
      return;
    }
    if (key === '.') {
      if (gram.includes('.')) return;
      if (gram === '') setGram('0.');
      else setGram((prev) => prev + '.');
      return;
    }
    
    // Max 3 decimal logic
    if (gram.includes('.')) {
      const parts = gram.split('.');
      if (parts[1].length >= 3) return;
    }
    
    if (key === '00' && (gram === '' || gram === '0')) return;
    if (key === '0' && gram === '0') return;

    setGram((prev) => {
      if (prev === '0') return key;
      return prev + key;
    });
  };

  const calculateResults = () => {
    const rawHarga = parseInt(harga || '0', 10);
    const rawGram = parseFloat(gram || '0');
    const totalSebelum = rawHarga * rawGram;
    const totalAkhir = pembulatanRibuan(totalSebelum);
    
    return {
      rawHarga,
      rawGram,
      totalSebelum,
      totalAkhir
    };
  };

  const res = calculateResults();

  const handleNextTab = () => {
    vibrate();
    if (activeTab === 2) {
      playSoftBeep();
    }
    if (activeTab < 3) setActiveTab((prev) => (prev + 1) as 1 | 2 | 3 | 4);
  };

  const handleReset = () => {
    setHarga('');
    setGram('');
    setCart([]);
    setActiveTab(1);
    setSelectedPreset(null);
    setIsGrandTotalOpen(false);
    setPendingAction(null);
    setIsCustomLabel(false);
  };

  const openLabelModal = () => {
    setItemLabel("");
    setIsCustomLabel(false);
    setIsLabelModalOpen(true);
  };

  const saveToCart = async (baseLabel: string, e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!baseLabel.trim()) baseLabel = "BARANG";
    
    let finalLabel = baseLabel.toUpperCase();
    let count = 1;
    while(cart.some(c => c.label === finalLabel)) {
      count++;
      finalLabel = `${baseLabel.toUpperCase()} ${count}`;
    }

    const item: CartItem = {
      id: Date.now().toString(),
      label: finalLabel,
      pricePerGram: res.rawHarga,
      gram: res.rawGram,
      totalSebelum: res.totalSebelum,
      totalAkhir: res.totalAkhir
    };
    
    setCart([...cart, item]);
    setIsLabelModalOpen(false);
    setIsCustomLabel(false);
    setItemLabel("");
    setHarga('');
    setGram('');
    setActiveTab(1);
    setSelectedPreset(null);

    if (pendingAction === 'GRAND_TOTAL') {
      setIsGrandTotalOpen(true);
      setPendingAction(null);
    }
  };

  const grandTotalAkhir = cart.reduce((acc, curr) => acc + curr.totalAkhir, 0);

  return (
    <div className="h-[100dvh] w-full bg-[#ffffff] text-[#111111] font-sans flex flex-col overflow-hidden">
        
        {/* Navbar */}
        <div className="flex bg-[#f9fafb] border-b border-[#e5e7eb] shrink-0">
          <button
            onClick={() => setActiveTab(1)}
            className={`flex-1 py-5 text-[14px] sm:text-base font-semibold uppercase tracking-[1px] transition-all border-b-[3px] outline-none ${activeTab === 1 ? 'text-[#16a34a] border-b-[#22c55e] bg-[#22c55e]/10' : 'text-[#6b7280] border-transparent hover:bg-black/5'}`}
          >
            Harga/Gr
          </button>
          <button
            onClick={() => setActiveTab(2)}
            className={`flex-1 py-5 text-[14px] sm:text-base font-semibold uppercase tracking-[1px] transition-all border-b-[3px] outline-none ${activeTab === 2 ? 'text-[#16a34a] border-b-[#22c55e] bg-[#22c55e]/10' : 'text-[#6b7280] border-transparent hover:bg-black/5'}`}
          >
            Gramasi
          </button>
          <button
            onClick={() => setActiveTab(3)}
            className={`flex-1 flex flex-col justify-center items-center py-4 text-[13px] sm:text-[14px] font-semibold uppercase tracking-[1px] transition-all border-b-[3px] outline-none ${activeTab === 3 ? 'text-[#16a34a] border-b-[#22c55e] bg-[#22c55e]/10' : 'text-[#6b7280] border-transparent hover:bg-black/5'}`}
          >
            Hasil
          </button>
          <button
            onClick={() => setActiveTab(4)}
            className={`flex-1 flex flex-col justify-center items-center py-4 text-[13px] sm:text-[14px] font-semibold uppercase tracking-[1px] transition-all border-b-[3px] outline-none ${activeTab === 4 ? 'text-[#16a34a] border-b-[#22c55e] bg-[#22c55e]/10' : 'text-[#6b7280] border-transparent hover:bg-black/5'}`}
          >
            Riwayat
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col relative bg-[#ffffff]">
          
          {cart.length > 0 && (
            <div className="absolute top-4 left-4 z-20">
               <button 
                onClick={() => setIsGrandTotalOpen(true)}
                className="bg-[#111111] text-white p-3 rounded-full shadow-lg flex items-center justify-center relative active:scale-95 transition-transform outline-none"
               >
                 <Receipt className="w-6 h-6" />
                 <span className="absolute -top-1 -right-1 bg-[#ef4444] text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full">
                   {cart.length}
                 </span>
               </button>
            </div>
          )}

          <AnimatePresence mode="wait">
            
            {/* TAB 1: HARGA */}
            {activeTab === 1 && (
              <motion.div
                key="tab1"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="absolute inset-0 flex flex-col bg-[#ffffff]"
              >
                <div className="flex-1 flex flex-col justify-center items-end px-8 py-10 bg-gradient-to-b from-[#f9fafb] to-[#ffffff] relative">
                  <div className="absolute top-4 right-4 sm:top-6 sm:right-6 z-10">
                    <button onClick={() => setIsSettingsOpen(true)} className="p-3 text-[#9ca3af] hover:text-[#111111] transition-colors outline-none shrink-0" aria-label="Pengaturan Harga">
                      <Settings className="w-7 h-7 sm:w-8 sm:h-8" />
                    </button>
                  </div>
                  <span className="text-[14px] text-[#6b7280] uppercase tracking-[1.5px] mb-4 font-sans flex items-center">
                    Harga per Gram
                    {selectedPreset && (
                      <span className="ml-3 px-2 py-1 bg-[#22c55e]/10 text-[#16a34a] rounded-md font-bold text-[12px] tracking-widest border border-[#22c55e]/20">
                        {selectedPreset}
                      </span>
                    )}
                  </span>
                  <div className="flex items-baseline gap-4 max-w-full">
                    <span className="text-3xl text-[#6b7280] font-bold mb-1 shrink-0">Rp</span>
                    <span className="text-[64px] sm:text-[80px] font-mono text-[#111111] tracking-tight break-all leading-tight">
                      {formatHargaKasir(harga)}
                    </span>
                  </div>
                </div>
                
                <div className="flex gap-3 overflow-x-auto px-6 py-4 bg-[#ffffff] shrink-0 border-y border-[#e5e7eb] [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                  {PRESET_ORDER.map((kadar) => {
                    const price = presets[kadar] || defaultPresets[kadar];
                    let label = "";
                    if (kadar.includes("KS")) label = "STANDARD";
                    if (kadar.includes("KP")) label = "PREMIUM";
                    return (
                    <button
                      key={kadar}
                      onClick={() => {
                        vibrate();
                        setHarga(price);
                        setSelectedPreset(kadar);
                      }}
                      className={`px-6 py-2 min-w-[80px] flex flex-col items-center justify-center rounded-[12px] transition-all outline-none border ${
                        selectedPreset === kadar 
                          ? 'bg-[#22c55e]/10 border-[#22c55e] shadow-sm' 
                          : 'bg-[#f3f4f6] border-[#e5e7eb] hover:bg-[#e5e7eb] active:scale-95'
                      }`}
                    >
                      <span className={`text-[16px] font-bold uppercase tracking-[1px] ${selectedPreset === kadar ? 'text-[#16a34a]' : 'text-[#111111]'}`}>{kadar}</span>
                      {label && <span className={`text-[10px] font-bold uppercase tracking-[1px] mt-0.5 ${selectedPreset === kadar ? 'text-[#15803d]' : 'text-[#6b7280]'}`}>{label}</span>}
                    </button>
                    );
                  })}
                </div>

                <div className="grid grid-cols-4 gap-[1px] bg-[#e5e7eb] p-[1px] shrink-0">
                  <Key btn="7" onClick={() => handleHargaInput('7')} />
                  <Key btn="8" onClick={() => handleHargaInput('8')} />
                  <Key btn="9" onClick={() => handleHargaInput('9')} />
                  <Key btn="⌫" className="text-[#ef4444] bg-[#ffffff] active:bg-[#f3f4f6]" onClick={() => handleHargaInput('⌫')} icon={<Delete className="w-6 h-6"/>} />
                  
                  <Key btn="4" onClick={() => handleHargaInput('4')} />
                  <Key btn="5" onClick={() => handleHargaInput('5')} />
                  <Key btn="6" onClick={() => handleHargaInput('6')} />
                  <Key btn="C" className="text-[#ef4444] bg-[#ffffff] active:bg-[#f3f4f6]" onClick={() => handleHargaInput('C')} />
                  
                  <Key btn="1" onClick={() => handleHargaInput('1')} />
                  <Key btn="2" onClick={() => handleHargaInput('2')} />
                  <Key btn="3" onClick={() => handleHargaInput('3')} />
                  <div className="bg-[#ffffff]" /> {/* Empty spot for decimal */}
                  
                  <Key btn="00" onClick={() => handleHargaInput('00')} />
                  <Key btn="0" onClick={() => handleHargaInput('0')} />
                  <button 
                    onClick={handleNextTab}
                    className="col-span-2 h-[12vh] min-h-[80px] sm:min-h-[100px] bg-[#f3f4f6] hover:bg-[#e5e7eb] active:bg-[#d1d5db] text-[#16a34a] transition-colors outline-none flex items-center justify-center font-medium text-[24px] uppercase tracking-[2px]"
                  >
                    LANJUT <ChevronRight className="w-8 h-8 ml-2" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* TAB 2: GRAMASI */}
            {activeTab === 2 && (
              <motion.div
                key="tab2"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="absolute inset-0 flex flex-col bg-[#ffffff]"
              >
                <div className="flex-1 flex flex-col justify-center items-end px-8 py-10 bg-gradient-to-b from-[#f9fafb] to-[#ffffff]">
                  <span className="text-[14px] text-[#6b7280] uppercase tracking-[1.5px] mb-4 font-sans">Gramasi (Gr)</span>
                  <div className="flex items-baseline gap-4 max-w-full">
                    <span className="text-[64px] sm:text-[80px] font-mono text-[#111111] tracking-tight break-all leading-tight">
                      {gram || '0'}
                    </span>
                    <span className="text-3xl text-[#6b7280] font-bold shrink-0">gr</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-4 gap-[1px] bg-[#e5e7eb] p-[1px] shrink-0">
                  <Key btn="7" onClick={() => handleGramInput('7')} />
                  <Key btn="8" onClick={() => handleGramInput('8')} />
                  <Key btn="9" onClick={() => handleGramInput('9')} />
                  <Key btn="⌫" className="text-[#ef4444] bg-[#ffffff] active:bg-[#f3f4f6]" onClick={() => handleGramInput('⌫')} icon={<Delete className="w-6 h-6"/>} />
                  
                  <Key btn="4" onClick={() => handleGramInput('4')} />
                  <Key btn="5" onClick={() => handleGramInput('5')} />
                  <Key btn="6" onClick={() => handleGramInput('6')} />
                  <Key btn="C" className="text-[#ef4444] bg-[#ffffff] active:bg-[#f3f4f6]" onClick={() => handleGramInput('C')} />
                  
                  <Key btn="1" onClick={() => handleGramInput('1')} />
                  <Key btn="2" onClick={() => handleGramInput('2')} />
                  <Key btn="3" onClick={() => handleGramInput('3')} />
                  <Key btn="." className="text-[#16a34a] bg-[#f3f4f6] hover:bg-[#e5e7eb] active:bg-[#d1d5db]" onClick={() => handleGramInput('.')} />
                  
                  <Key btn="00" onClick={() => handleGramInput('00')} />
                  <Key btn="0" onClick={() => handleGramInput('0')} />
                  <button 
                    onClick={handleNextTab}
                    className="col-span-2 h-[12vh] min-h-[80px] sm:min-h-[100px] bg-[#f3f4f6] hover:bg-[#e5e7eb] active:bg-[#d1d5db] text-[#16a34a] transition-colors outline-none flex items-center justify-center font-medium text-[24px] uppercase tracking-[2px]"
                  >
                    HITUNG <Check className="w-8 h-8 ml-3" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* TAB 3: HASIL */}
            {activeTab === 3 && (
              <motion.div
                key="tab3"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.15 }}
                className="absolute inset-0 flex flex-col bg-[#ffffff] p-6 overflow-y-auto"
              >
                <div className="flex-1 flex flex-col py-2 justify-center">
                  
                  <div className="flex justify-between items-center py-6 border-b border-[#e5e7eb]">
                    <span className="text-[16px] sm:text-[20px] text-[#6b7280]">Harga/Gram</span>
                    <span className="text-[#111111] font-mono text-[20px] sm:text-[24px]">Rp {formatRupiah(res.rawHarga)}</span>
                  </div>
                  <div className="flex justify-between items-center py-6 border-b border-[#e5e7eb]">
                    <span className="text-[16px] sm:text-[20px] text-[#6b7280]">Gramasi</span>
                    <span className="text-[#111111] font-mono text-[20px] sm:text-[24px]">{res.rawGram} gr</span>
                  </div>
                  <div className="flex justify-between items-center py-6 border-b border-[#e5e7eb]">
                    <span className="text-[16px] sm:text-[20px] text-[#6b7280]">Subtotal</span>
                    <span className="text-[#6b7280] font-mono text-[20px] sm:text-[24px] line-through">Rp {formatRupiah(res.totalSebelum)}</span>
                  </div>
                  
                  <div className="mt-10 p-8 sm:p-10 bg-[#f9fafb] rounded-[24px] border border-[#e5e7eb] text-center shadow-sm relative">
                    <div className="text-[14px] sm:text-[16px] text-[#6b7280] uppercase tracking-[2px] mb-4 font-sans">Total Akhir</div>
                    <div className="text-[48px] sm:text-[64px] font-bold text-[#16a34a] mt-2 font-mono tracking-tighter break-words leading-none">
                      Rp <AnimatedNumber value={res.totalAkhir} />
                    </div>
                  </div>

                </div>

                <div className="flex flex-col gap-3 shrink-0 pb-4">
                  <button 
                    onClick={openLabelModal}
                    className="w-full h-[80px] sm:h-[90px] rounded-[20px] bg-[#2563eb]/10 hover:bg-[#2563eb]/20 active:bg-[#2563eb]/30 text-[#2563eb] transition-colors outline-none flex items-center justify-center font-medium text-[20px] sm:text-[24px] uppercase tracking-[2px]"
                  >
                    <Plus className="w-6 h-6 mr-3" />
                    Tambah Barang
                  </button>

                  <div className="flex gap-3">
                    <button 
                      onClick={handleReset}
                      className="flex-1 h-[80px] sm:h-[90px] rounded-[20px] bg-[#f3f4f6] hover:bg-[#e5e7eb] active:bg-[#d1d5db] text-[#ef4444] transition-colors outline-none flex items-center justify-center font-medium text-[16px] sm:text-[20px] uppercase tracking-[1px]"
                    >
                      <RotateCcw className="w-5 h-5 mr-2" />
                      Reset
                    </button>
                    {(cart.length > 0 || res.rawHarga > 0) && (
                      <button 
                        onClick={() => {
                          playSoftBeep();
                          if (res.rawHarga > 0 && res.rawGram > 0) {
                            setPendingAction('GRAND_TOTAL');
                            openLabelModal();
                          } else {
                            setIsGrandTotalOpen(true);
                          }
                        }}
                        className={`flex-[2] h-[80px] sm:h-[90px] rounded-[20px] transition-colors outline-none flex items-center justify-center font-medium text-[16px] sm:text-[20px] uppercase tracking-[1px] ${cart.length > 0 ? 'bg-[#16a34a] hover:bg-[#15803d] active:bg-[#166534] text-white shadow-lg' : 'bg-[#f3f4f6] text-[#6b7280]'}`}
                      >
                        <Receipt className="w-5 h-5 mr-2" />
                        Grand Total {cart.length > 0 && <span className="ml-2 bg-white/20 px-2 py-0.5 rounded-full text-sm">{cart.length}</span>}
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 4: RIWAYAT */}
            {activeTab === 4 && (
              <motion.div
                key="tab4"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.15 }}
                className="absolute inset-0 flex flex-col bg-[#f9fafb] p-6 overflow-y-auto"
              >
                <div className="flex justify-between items-center mb-6 shrink-0 mt-2">
                  <h2 className="text-[20px] font-bold text-[#111111] uppercase tracking-[1px]">Riwayat Transaksi</h2>
                  {riwayatList.length > 0 && (
                    <button 
                      onClick={async () => {
                        if (confirm("Hapus semua riwayat transaksi?")) {
                          await hapusSemuaTransaksi();
                          fetchRiwayat();
                        }
                      }}
                      className="text-[#ef4444] font-bold text-[14px] uppercase p-2 hover:bg-[#fee2e2] rounded-[8px] transition-colors"
                    >
                      Hapus Semua
                    </button>
                  )}
                </div>

                {isLoadingRiwayat ? (
                  <div className="flex-1 flex items-center justify-center text-[#6b7280] font-medium">
                    Memuat riwayat...
                  </div>
                ) : riwayatList.length === 0 ? (
                  <div className="flex-1 flex items-center justify-center text-[#6b7280] font-medium">
                    Belum ada riwayat transaksi.
                  </div>
                ) : (
                  <div className="flex flex-col gap-4 pb-10">
                    {riwayatList.map((item) => (
                      <div key={item.id} className="bg-[#ffffff] p-5 rounded-[16px] border border-[#e5e7eb] shadow-sm flex flex-col gap-3 relative cursor-pointer hover:border-[#16a34a] transition-colors" onClick={() => setSelectedRiwayat(item)}>
                        <div className="flex justify-between items-start pr-10">
                          <div className="flex flex-col">
                            <span className="font-bold text-[#111111] text-[16px] uppercase tracking-[1px]">{item.customerName}</span>
                            <span className="text-[12px] font-medium text-[#6b7280] mt-1">{new Date(item.tanggal).toLocaleString('id-ID')}</span>
                          </div>
                          <button 
                            onClick={async (e) => {
                              e.stopPropagation();
                              if (item.id && confirm("Hapus transaksi ini?")) {
                                await hapusTransaksi(item.id);
                                fetchRiwayat();
                              }
                            }}
                            className="absolute top-4 right-4 p-2 text-[#9ca3af] hover:text-[#ef4444] hover:bg-[#fee2e2] rounded-[8px] transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                        <div className="flex justify-between items-end border-t border-[#f3f4f6] pt-3 mt-1">
                          <span className="text-[#6b7280] font-medium text-[14px]">{item.barangList?.length || 0} Barang</span>
                          <span className="font-mono font-bold text-[#16a34a] text-[20px]">Rp {formatRupiah(item.grandTotal)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* DETAIL RIWAYAT MODAL */}
            {selectedRiwayat && (
              <div className="absolute inset-0 z-50 bg-[#f9fafb] flex flex-col">
                <div className="flex items-center justify-between p-4 sm:p-6 bg-[#ffffff] border-b border-[#e5e7eb] sticky top-0 z-10 shrink-0">
                  <div className="flex flex-col">
                    <h2 className="text-[20px] font-bold text-[#111111] uppercase tracking-[1px]">Detail Transaksi</h2>
                    <span className="text-[14px] text-[#6b7280] font-medium">{selectedRiwayat.customerName}</span>
                  </div>
                  <button 
                    onClick={() => setSelectedRiwayat(null)}
                    className="p-3 text-[#111111] hover:bg-[#f3f4f6] active:bg-[#e5e7eb] rounded-full transition-colors outline-none"
                  >
                    <X className="w-7 h-7" />
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {(selectedRiwayat.barangList || []).map((item, idx) => (
                    <div key={idx} className="flex flex-col gap-3 p-5 bg-[#ffffff] border border-[#e5e7eb] rounded-[16px] shadow-sm">
                      <div className="flex justify-between items-start">
                        <span className="text-[16px] font-bold text-[#111111] tracking-[1px]">{item.label}</span>
                      </div>
                      <div className="flex justify-between items-center bg-[#f9fafb] p-3 rounded-[8px]">
                        <span className="text-[14px] text-[#6b7280] font-mono">{item.gram} gr × Rp {formatRupiah(item.harga)}</span>
                        <span className="text-[18px] font-bold text-[#111111] font-mono">Rp {formatRupiah(item.totalAkhir)}</span>
                      </div>
                    </div>
                  ))}
                  
                  <div className="mt-8 p-8 bg-[#f9fafb] rounded-[24px] border border-[#e5e7eb] text-center shadow-sm">
                    <div className="text-[14px] text-[#6b7280] uppercase tracking-[2px] mb-2 font-sans">Grand Total</div>
                    <div className="text-[40px] sm:text-[48px] font-bold text-[#16a34a] font-mono tracking-tighter break-words leading-none">
                      Rp {formatRupiah(selectedRiwayat.grandTotal)}
                    </div>
                  </div>
                </div>
              </div>
            )}
            
          </AnimatePresence>
        </div>

        {/* CUSTOMER NAME MODAL */}
        <AnimatePresence>
          {isCustomerModalOpen && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              className="absolute inset-0 bg-black/60 z-50 flex items-end sm:items-center justify-center p-4"
            >
              <motion.div 
                initial={{ y: 50, opacity: 0 }} 
                animate={{ y: 0, opacity: 1 }} 
                exit={{ y: 20, opacity: 0 }}
                className="bg-[#ffffff] w-full max-w-sm rounded-[24px] overflow-hidden shadow-2xl border border-[#e5e7eb]"
              >
                <div className="p-6 bg-[#f9fafb] border-b border-[#e5e7eb] flex justify-between items-center">
                  <h3 className="font-bold text-[18px] text-[#111111] uppercase tracking-[1px]">Simpan Transaksi</h3>
                  <button onClick={() => {
                    setIsCustomerModalOpen(false);
                    setCustomerName('');
                  }} className="p-2 text-[#9ca3af] hover:text-[#111111] rounded-full hover:bg-[#e5e7eb] transition-colors outline-none"><X className="w-5 h-5"/></button>
                </div>
                <div className="p-6">
                  <label className="text-[14px] text-[#6b7280] font-medium tracking-[1px] uppercase mb-2 block">NAMA CUSTOMER</label>
                  <input 
                    type="text" 
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value.toUpperCase())}
                    placeholder="CONTOH: BUDI"
                    className="w-full text-[24px] font-bold text-[#111111] bg-[#f9fafb] border border-[#e5e7eb] rounded-[12px] px-4 py-4 outline-none focus:border-[#111111] transition-colors placeholder:text-[#d1d5db]"
                    autoFocus
                  />
                  <div className="grid grid-cols-2 gap-3 mt-8">
                    <button 
                      onClick={() => {
                        setIsCustomerModalOpen(false);
                        setCustomerName('');
                      }} 
                      className="py-4 bg-[#f3f4f6] text-[#4b5563] font-bold rounded-[12px] hover:bg-[#e5e7eb] active:bg-[#d1d5db] transition-colors outline-none uppercase tracking-[1px]"
                    >
                      Batal
                    </button>
                    <button 
                      onClick={async () => {
                        if (customerName.trim() === '') return;
                        
                        const items = cart.map(c => ({
                            label: c.label,
                            harga: c.pricePerGram,
                            gram: c.gram,
                            totalAwal: c.totalSebelum,
                            totalAkhir: c.totalAkhir
                        }));

                        if (res.rawHarga > 0 && res.rawGram > 0) {
                            // Automatically add the currently calculated item if not manually added
                            items.push({
                                label: "BARANG LANGSUNG",
                                harga: res.rawHarga,
                                gram: res.rawGram,
                                totalAwal: res.totalSebelum,
                                totalAkhir: res.totalAkhir
                            });
                        }

                        const gt = grandTotalAkhir + (res.rawHarga > 0 ? res.totalAkhir : 0);

                        const data: Transaksi = {
                          customerName: customerName.trim(),
                          tanggal: new Date().toISOString(),
                          grandTotal: gt,
                          barangList: items
                        };

                        try {
                          await simpanTransaksi(data);
                          handleReset();
                          setCustomerName('');
                          setIsCustomerModalOpen(false);
                          setActiveTab(4);
                        } catch (err) {
                          console.error("Gagal simpan transaksi", err);
                        }
                      }} 
                      className="py-4 bg-[#111111] text-white font-bold rounded-[12px] hover:bg-black active:bg-[#1f2937] transition-colors outline-none uppercase tracking-[1px] disabled:opacity-50"
                      disabled={customerName.trim() === ''}
                    >
                      SIMPAN
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Settings Modal */}
        <AnimatePresence>
          {isSettingsOpen && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 z-50 bg-[#ffffff] flex flex-col"
            >
              <div className="flex items-center justify-between px-8 py-6 border-b border-[#e5e7eb] bg-[#f9fafb]">
                <h2 className="text-[20px] font-semibold tracking-[1px] uppercase">Pengaturan Harga</h2>
                <button onClick={() => setIsSettingsOpen(false)} className="p-2 text-[#9ca3af] hover:text-[#111111] transition-colors outline-none">
                  <X className="w-8 h-8" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto px-8 py-6 space-y-6 bg-[#ffffff]">
                {PRESET_ORDER.map((kadar) => {
                  const price = presets[kadar] || defaultPresets[kadar];
                  return (
                  <div key={kadar} className="flex flex-col gap-3">
                    <label className="text-[#6b7280] text-[14px] font-medium tracking-[1px] uppercase">{kadar}</label>
                    <div className="relative flex items-center">
                      <span className="absolute left-6 text-[#9ca3af] font-mono text-[20px]">Rp</span>
                      <input 
                        type="text"
                        inputMode="numeric"
                        value={price ? price.replace(/\B(?=(\d{3})+(?!\d))/g, ".") : ''}
                        onChange={(e) => {
                          const rawValue = e.target.value.replace(/\D/g, '');
                          setPresets(prev => ({ ...prev, [kadar]: rawValue }));
                        }}
                        className="w-full bg-[#ffffff] border border-[#d1d5db] text-[#111111] rounded-[16px] pl-16 pr-6 py-5 font-mono text-[24px] outline-none focus:border-[#22c55e] transition-colors"
                      />
                    </div>
                  </div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Add Item Label Modal */}
        <AnimatePresence>
          {isLabelModalOpen && (
            <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full max-w-sm bg-white rounded-[24px] shadow-2xl p-6 flex flex-col gap-6"
              >
                <div className="flex flex-col gap-2">
                  <h3 className="text-[20px] font-bold text-[#111111]">Simpan Barang</h3>
                  <p className="text-[#6b7280] text-[14px]">Pilih/masukkan label barang saat ini.</p>
                </div>
                
                {!isCustomLabel ? (
                  <div className="flex flex-col gap-3">
                    <button onClick={() => saveToCart("CINCIN")} className="py-4 bg-[#f3f4f6] hover:bg-[#e5e7eb] active:bg-[#d1d5db] rounded-[16px] font-bold text-[#111111] uppercase tracking-[1px] transition-colors outline-none">CINCIN</button>
                    <button onClick={() => saveToCart("GELANG")} className="py-4 bg-[#f3f4f6] hover:bg-[#e5e7eb] active:bg-[#d1d5db] rounded-[16px] font-bold text-[#111111] uppercase tracking-[1px] transition-colors outline-none">GELANG</button>
                    <button onClick={() => saveToCart("ANTING")} className="py-4 bg-[#f3f4f6] hover:bg-[#e5e7eb] active:bg-[#d1d5db] rounded-[16px] font-bold text-[#111111] uppercase tracking-[1px] transition-colors outline-none">ANTING</button>
                    <button onClick={() => { setIsCustomLabel(true); setTimeout(() => labelInputRef.current?.focus(), 100); }} className="py-4 bg-[#2563eb]/10 hover:bg-[#2563eb]/20 active:bg-[#2563eb]/30 rounded-[16px] font-bold text-[#2563eb] uppercase tracking-[1px] transition-colors outline-none">CUSTOM MANUAL</button>
                    
                    <button onClick={() => { setIsLabelModalOpen(false); setPendingAction(null); }} className="mt-2 py-4 bg-transparent text-[#6b7280] font-bold rounded-[16px] hover:bg-[#f3f4f6] transition-colors outline-none">Batal</button>
                  </div>
                ) : (
                  <form onSubmit={(e) => saveToCart(itemLabel, e)} className="flex flex-col gap-6">
                    <input
                      ref={labelInputRef}
                      type="text"
                      placeholder="NAMA BARANG..."
                      value={itemLabel}
                      onChange={(e) => setItemLabel(e.target.value.toUpperCase())}
                      className="w-full bg-[#f9fafb] border border-[#d1d5db] text-[#111111] rounded-[16px] px-6 py-4 text-[18px] uppercase outline-none focus:border-[#2563eb] transition-colors"
                    />
                    
                    <div className="flex gap-3">
                      <button
                        type="button"
                        onClick={() => { setIsCustomLabel(false); setItemLabel(""); }}
                        className="flex-1 py-4 bg-[#f3f4f6] text-[#6b7280] font-bold rounded-[16px] hover:bg-[#e5e7eb] active:bg-[#d1d5db] transition-colors outline-none"
                      >
                        Kembali
                      </button>
                      <button
                        type="submit"
                        disabled={!itemLabel.trim()}
                        className="flex-1 py-4 bg-[#2563eb] text-white font-bold rounded-[16px] hover:bg-[#1d4ed8] active:bg-[#1e40af] disabled:opacity-50 disabled:active:bg-[#2563eb] transition-colors outline-none"
                      >
                        Simpan
                      </button>
                    </div>
                  </form>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Grand Total Modal */}
        <AnimatePresence>
          {isGrandTotalOpen && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 z-50 bg-[#ffffff] flex flex-col"
            >
              <div className="flex items-center justify-between px-6 py-5 border-b border-[#e5e7eb] bg-[#f9fafb] shrink-0">
                <h2 className="text-[18px] font-semibold tracking-[1px] uppercase text-[#111111]">Grand Total</h2>
                <button onClick={() => setIsGrandTotalOpen(false)} className="p-2 text-[#9ca3af] hover:text-[#111111] transition-colors outline-none bg-[#f3f4f6] rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 bg-[#ffffff]">
                {cart.length === 0 && res.rawHarga === 0 && (
                  <div className="h-full flex items-center justify-center text-[#9ca3af]">
                    Belum ada barang.
                  </div>
                )}
                
                <div className="flex flex-col gap-4">
                  {cart.map((item, idx) => (
                    <div key={item.id} className="p-4 bg-[#f9fafb] rounded-[16px] border border-[#e5e7eb] flex flex-col gap-2">
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-[#111111] text-[16px]">{item.label}</span>
                        <span className="font-mono font-bold text-[#111111] text-[18px]">Rp {formatRupiah(item.totalAkhir)}</span>
                      </div>
                      <div className="flex justify-between items-center text-[#6b7280] text-[14px]">
                        <span>{item.gram} gr × Rp {formatRupiah(item.pricePerGram)}</span>
                        <span className="line-through">Rp {formatRupiah(item.totalSebelum)}</span>
                      </div>
                    </div>
                  ))}
                  
                  {res.rawHarga > 0 && cart.length > 0 && (
                     <div className="p-4 bg-white/50 border-2 border-dashed border-[#e5e7eb] rounded-[16px] flex flex-col gap-2 opacity-60">
                        <div className="text-[12px] uppercase tracking-wider text-[#9ca3af] font-bold">Belum Tersimpan</div>
                        <div className="flex justify-between items-start">
                          <span className="font-bold text-[#111111] text-[16px]">Saat ini</span>
                          <span className="font-mono font-bold text-[#111111] text-[18px]">Rp {formatRupiah(res.totalAkhir)}</span>
                        </div>
                     </div>
                  )}
                  {res.rawHarga > 0 && cart.length === 0 && (
                    <div className="p-4 bg-[#f9fafb] rounded-[16px] border border-[#e5e7eb] flex flex-col gap-2">
                     <div className="flex justify-between items-start">
                       <span className="font-bold text-[#111111] text-[16px]">Barang Saat Ini</span>
                       <span className="font-mono font-bold text-[#111111] text-[18px]">Rp {formatRupiah(res.totalAkhir)}</span>
                     </div>
                   </div>
                  )}
                </div>
              </div>
              
              <div className="p-6 bg-[#f9fafb] border-t border-[#e5e7eb] shrink-0">
                 <div className="flex justify-between items-end mb-6">
                    <span className="uppercase tracking-[1px] text-[#6b7280] font-semibold">Total Keseluruhan</span>
                    <span className="text-[36px] sm:text-[42px] font-mono font-bold text-[#16a34a] leading-none">
                      Rp <AnimatedNumber value={grandTotalAkhir + (res.rawHarga > 0 && cart.length > 0 ? res.totalAkhir : 0) + (res.rawHarga > 0 && cart.length === 0 ? res.totalAkhir : 0)} />
                    </span>
                 </div>
                 
                 <div className="flex gap-3">
                   <button 
                    onClick={handleReset}
                    className="flex-1 py-5 rounded-[16px] bg-[#f3f4f6] text-[#6b7280] hover:bg-[#e5e7eb] active:bg-[#d1d5db] transition-colors outline-none flex items-center justify-center font-bold text-[14px] sm:text-[16px] uppercase tracking-[1px]"
                  >
                    Reset
                  </button>
                  <button 
                    onClick={() => {
                        setIsGrandTotalOpen(false);
                        setIsCustomerModalOpen(true);
                    }}
                    className="flex-[2] py-5 rounded-[16px] bg-[#16a34a] hover:bg-[#15803d] active:bg-[#166534] text-white transition-colors outline-none flex items-center justify-center font-bold text-[14px] sm:text-[16px] uppercase tracking-[1px]"
                  >
                    Simpan Transaksi
                  </button>
                 </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

    </div>
  );
}

// Reusable Key Button Component
function Key({ btn, onClick, active, className, icon }: { btn: string, onClick: () => void, active?: boolean, className?: string, icon?: React.ReactNode }) {
  return (
    <button
      onClick={() => {
        vibrate();
        onClick();
      }}
      className={`h-[12vh] min-h-[80px] sm:min-h-[100px] flex items-center justify-center text-[32px] sm:text-[40px] font-medium outline-none select-none transition-colors 
      ${className || 'bg-[#ffffff] hover:bg-[#f9fafb] active:bg-[#f3f4f6] text-[#111111]'}`}
    >
      {icon ? icon : btn}
    </button>
  );
}

