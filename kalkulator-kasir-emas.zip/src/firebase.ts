import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, getDocs, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export interface BarangItem {
  label: string;
  harga: number;
  gram: number;
  totalAwal: number;
  totalAkhir: number;
}

export interface Transaksi {
  id?: string;
  customerName: string;
  tanggal: string;
  grandTotal: number;
  barangList: BarangItem[];
}

export async function simpanTransaksi(data: Transaksi) {
  await addDoc(collection(db, "transaksi"), {
    customerName: data.customerName,
    tanggal: new Date().toISOString(),
    grandTotal: data.grandTotal,
    barangList: data.barangList
  });
}

export async function loadTransaksi(): Promise<Transaksi[]> {
  const q = query(collection(db, 'transaksi'), orderBy('tanggal', 'desc'));
  const snapshot = await getDocs(q);
  let list: Transaksi[] = [];

  snapshot.forEach((doc) => {
    list.push({ id: doc.id, ...(doc.data() as Transaksi) });
  });

  return list;
}

export async function hapusTransaksi(id: string) {
  if (!id) return;
  await deleteDoc(doc(db, "transaksi", id));
}

export async function hapusSemuaTransaksi() {
  const snapshot = await getDocs(collection(db, 'transaksi'));
  for (const document of snapshot.docs) {
    await deleteDoc(doc(db, "transaksi", document.id));
  }
}
